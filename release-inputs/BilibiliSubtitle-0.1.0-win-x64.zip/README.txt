主播双语字幕 Windows x64 软件版

请运行 BilibiliSubtitle-Setup.exe 安装。软件安装到当前用户，不需要管理员权限。
启动使用桌面“主播双语字幕软件版”或开始菜单“主播双语字幕”。
首次进入“软件设置与更新”下载环境和模型，也可以选择已有环境目录。
环境包括独立Python、GPU运行依赖、Whisper large-v3、CAM++与官方Codex CLI。
模型首次下载约3GiB以上，请预留至少12GiB磁盘空间（含下载、解压和旧版本）。
需要Windows 10/11 x64、.NET Framework 4.8、WebView2 Runtime及NVIDIA显卡驱动。
当前Whisper使用FP16，建议至少8GiB显存。没有符合条件GPU时不承诺可运行。
已有Codex登录会沿用；新电脑需用自己的ChatGPT账号完成一次官方CLI登录。
软件不会分发账号、Token、测试声纹或录音。

软件内“检查更新”从GitHub Releases读取新版本；“下载并安装更新”校验后停止后台、
安装到新版本目录并重启。旧版本保留，模型、用户设置、声纹和登录不随程序更新覆盖。
用户数据默认在 %LOCALAPPDATA%\BilibiliSubtitlePrototype。
程序安装在 %LOCALAPPDATA%\Programs\BilibiliSubtitle。
卸载程序文件会保留用户数据；不会删除你的Codex登录。

本版本为功能预览。既有识别缺口和翻译长尾尚未修复，不能保证三秒内双语显示。
第三方组件各有许可，详见组件包内license/notice和来源记录。EXE未购买代码签名证书。