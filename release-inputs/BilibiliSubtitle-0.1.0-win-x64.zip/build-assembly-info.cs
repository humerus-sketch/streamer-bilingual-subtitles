using System.Reflection;
[assembly: AssemblyTitle("主播双语字幕")]
[assembly: AssemblyProduct("主播双语字幕")]
[assembly: AssemblyCompany("humerus-sketch")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: AssemblyInformationalVersion("0.1.0")]