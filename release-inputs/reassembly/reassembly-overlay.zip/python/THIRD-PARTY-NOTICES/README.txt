This private runtime is only for Streamer Bilingual Subtitles. Preserve all package license files.
NVIDIA CUDA cuBLAS/cublasLt/nvblas are application redistributables under the supplied CUDA EULA;
the runtime is not a standalone NVIDIA SDK and is for NVIDIA GPU systems only.
NVIDIA driver, Microsoft UCRT/VC Runtime and WebView2 Evergreen are external prerequisites.
SoXR is LGPL-2.1-or-later. PyAV bundles FFmpeg; see their supplied license/notice/source information.
No upstream package license is replaced by the application license.
