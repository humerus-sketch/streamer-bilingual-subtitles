Corresponding source and build-recipe evidence for the unmodified bundled media libraries.
Recipes are fixed to pyav-ffmpeg commit bac889417e26be29615cb6a3f38318151fed55cd (release 9.0.2-1).
Every codec source archive is verified against that exact recipe SHA256.
PyAV source is fixed to the installed v19.0.1 tag commit; Python-SoXR 1.1.0 uses its hash-verified sdist.
Build instructions: see recipes/pyav-ffmpeg/.github/workflows/build-ffmpeg.yml,
scripts/build-ffmpeg.py, scripts/cibuildpkg.py, scripts/pkg.py, and every patches/*.patch.
The vendor FFmpeg patch reclassifies x264/x265; individual component licenses remain applicable.
See source-manifest.json unresolved entries before claiming public redistribution clearance.

MSYS2 COMPLETE SOURCES
See MSYS2-provenance.json: libgcc/libstdc++ GCC16.1.0-5, libiconv1.19-1,
zlib1.3.2-2, libwinpthread14.0.0.r92/r98. Complete .src.tar.zst files include
upstream source archives, PKGBUILD, patches and package build instructions.
Both winpthread variants are retained because their executable/read-only sections match.
The matching method compares entire .text/.rdata sections, since vendor strip/repair
changes writable PE bookkeeping; this is not a claim of identical whole-DLL file hashes.

REPLACING DYNAMIC LIBRARIES
Stop the application, rebuild compatible FFmpeg/codec libraries using the retained recipes,
and replace the DLLs in runtime/python/Lib/site-packages/av.libs. Keep the installed repaired
filenames/import ABI or rebuild/repair the PyAV extension against the new DLLs.
The application does not enforce runtime-file hashes after installation to prevent replacement.
For Python-SoXR, rebuild its extension from the complete supplied sdist (including libsoxr)
and replace its .pyd. Runtime updates may replace bundled libraries; retain your local build.

LICENSE BOUNDARIES
All individual upstream licenses apply. The vendor FFmpeg patch changes GPL classification
labels for x264/x265, not their independent legal rights. The included source/build package
and licensing terms must remain available beside the binaries. No legal certification is claimed.
